#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <limits.h>
#include <fcntl.h>
int main(int argc, char **argv)
{
    if(argc < 3){
        return 0;
    }
    int fd[2];
    pipe(fd);
    int p1 = fork();
    if(p1 == -1) return -1;
    if(p1 == 0){
        close(fd[0]);
        dup2(fd[1], 1);
        close(fd[1]);
        execl(argv[1], argv[1], NULL);
        return 1;
    }
}